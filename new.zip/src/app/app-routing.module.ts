import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


const routes: Routes = [
  { path: '',
      loadChildren: () => import('./modules/question/question.module').then(m => m.QuestionModule) },
  { path: 'choice',
      loadChildren: () => import('./modules/choice/choice.module').then(m => m.ChoiceModule) },
      { path: 'sharedList',
      loadChildren: () => import('./modules/sharedlist/sharedlist.module').then(m => m.SharedlistModule) },
  { path: '**', redirectTo: '', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
