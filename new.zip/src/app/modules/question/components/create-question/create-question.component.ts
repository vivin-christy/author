import { Component, OnInit, Inject } from '@angular/core';
import { QuestiondashboardComponent } from '../question-dashboard/question-dashboard.component';
import * as AppConst from '../../../../app.config';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Observable } from 'rxjs';
import { List, categoryList, sharedList, choiceList } from '../../../../models/list.model';
import { map, startWith } from 'rxjs/operators';
import { QuestionService } from '../../../../services/question.service';
import { RequiredMatch } from '../../../../shared/requiredMatch';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { NotificationService } from 'src/app/services/notification.service';
import { CommonService } from 'src/app/services/common.service';
import { QuestionsModel } from 'src/app/models/questions.model';

@Component({
  selector: 'app-create-question',
  templateUrl: './create-question.component.html',
  styleUrls: ['./create-question.component.scss']
})
export class CreatequestionComponent implements OnInit {


  constructor(
   // @Inject(MAT_DIALOG_DATA) public data: QuestionsModel,
    private createQuestionRef: MatDialogRef<QuestiondashboardComponent>,
    private quesService: QuestionService,
    private toastorService: NotificationService,
    private commonService: CommonService
    // @Inject(MAT_BOTTOM_SHEET_DATA) public data: any
    ) { 
      
     }
  public createQuesForm: FormGroup;
  public label = AppConst.AppConfig.settings['question'];
  public validationMsg = AppConst.AppConfig.settings['validationMsg'];
  public globalResponse: any;
  public url = 'questions';
 // public inputData = new QuestionsModel();
 toppings = new FormControl();
 toppingList: string[] = [' FUTURE ACTIVITY', 'FAVORITE SHOWS', 'HOST ADJECTIVES', 'CLUSTER', 'ANCHOR', 'FIRST FAVORITE'];
radioItem = [
  {id: 1, value: 'POSITIVE', color:'green'},
  {id: 2, value: 'NEGATIVE', color: 'red'},
  {id: 3, value: 'NEUTRAL', color: ''}
];

chosenItem = this.radioItem[0].value;

  filteredCategory: Observable<List[]>;
  filteredSharedList: Observable<List[]>;
  filteredChoice: Observable<List[]>;

  categoryList: categoryList[] = [];
  sharedList: sharedList[]=  [
    {'sharedListId': 1, 'sharedListDesc': 'Value'},
    {'sharedListId': 2, 'sharedListDesc': 'sdfsd'}
  ];
  choiceList: choiceList[]=   [
    {'choiceListId': 1, 'choiceListDesc': 'Frequently'},
    {'choiceListId': 2, 'choiceListDesc': 'Rarely'}
  ];

initializeFormGroup() {
  console.log('inizialse');
  this.createQuesForm.setValue({
    questionCategory: '',
    genericText: '',
    questionPosNegFlag: this.radioItem[0].value,
    percentileYn: true,
    summRptYn: true,
    activeYn: false,
    questionSharedList: '',
    choiceList: ''
  });
}


  _filterValue(val: any, ArrList: any, Type:any) {
    if(Type=== 'categoryList') {
      const name = val.questionCategoryDesc || val; // val can be List or string
      const list = ArrList.filter(
        option => option.questionCategoryDesc.toLowerCase().indexOf(name.toLowerCase()) === 0 );
      return ( list.length > 0 ? list : [{questionCategoryId: null, questionCategoryDesc: 'No record found'} as any]);
    } else if(Type=== 'sharedList'){
      const name = val.sharedListDesc || val; // val can be List or string
      const list = ArrList.filter(
        option => option.sharedListDesc.toLowerCase().indexOf(name.toLowerCase()) === 0 );
      return list;
    }else if(Type=== 'choiceList'){
      const name = val.choiceListDesc || val; // val can be List or string
      const list = ArrList.filter(
        option => option.choiceListDesc.toLowerCase().indexOf(name.toLowerCase()) === 0 );
      return list;
    }
    
}


   categoryDisplayFn(filterBy): string {
     return filterBy ? filterBy.questionCategoryDesc : filterBy;
   }
   sharedDisplayFn(filterBy): string {
    return filterBy ? filterBy.sharedListDesc : filterBy;
  }
  choiceDisplayFn(filterBy): string {
    console.log('choiceListDesc', filterBy.choiceListDesc);
    return filterBy ? filterBy.choiceListDesc : filterBy;
  }

  openLink(event: MouseEvent): void {
    this.createQuestionRef.close();
    event.preventDefault();
  }

  ngOnInit() {
    this.getCategory();
    this.getSharedList();
    this.getChoiceList();
    console.log(AppConst.AppConfig.settings);
    this.createQuesForm = new FormGroup({
     questionCategory: new FormControl('', [Validators.required, RequiredMatch]),
     genericText: new FormControl('', [Validators.required]),
     questionPosNegFlag: new FormControl('POSITIVE', [Validators.required]),
     percentileYn: new FormControl(true),
     summRptYn: new FormControl(false),
     activeYn: new FormControl(true),
     questionSharedList: new FormControl(''),
     choiceList: new FormControl('')
   });
   }

// Validation Error Message
  public hasError = (controlName: string, errorName: string) => {
    return this.createQuesForm.controls[controlName].hasError(errorName);
  }

// Set Slider field value
  onChange(controlName: string, e) {
    if (e.checked === true) {
      this.createQuesForm.controls[controlName].setValue(true);
    } else {
      this.createQuesForm.controls[controlName].setValue(false);
    }
  }

  onClose() {
    this.createQuesForm.reset();
    this.initializeFormGroup();
  }

// Auto Populate for each dropdown
  // Category API
  getCategory(): void {
     this.quesService.getCategoryList().subscribe(data => {
       this.categoryList = data;
       this.filteredCategory = this.createQuesForm.controls.questionCategory.valueChanges
       .pipe(
          startWith(''),
          map( category => category ?  this._filterValue(category, this.categoryList, 'categoryList' ) : this.categoryList.slice())
      );
     });
   }

  // Shared List API
  getSharedList(): void {
    this.quesService.getSharedList().subscribe(data => {
     // this.sharedList = data;
      this.filteredSharedList = this.createQuesForm.controls.questionSharedList.valueChanges.pipe(
        startWith(''),
        map( category => category ?  this._filterValue(category, this.sharedList, 'sharedList' ) : this.sharedList.slice())
     );
  
    });
  }
  // Choice List API
  getChoiceList(): void {
    this.quesService.getChoiceList().subscribe(data => {
     // this.choiceList = data;
      this.filteredChoice = this.createQuesForm.controls.choiceList.valueChanges.pipe(
        startWith(''),
        map( category => category ?  this._filterValue(category, this.choiceList, 'choiceList' ) : this.choiceList.slice())
     );
    });
  }

   onChangeSharedList(sharedValue){
     console.log('test');
     this.quesService.getChoiceList().subscribe(data => {
      // this.choiceList = data;
      this.filteredChoice = this.createQuesForm.controls.choiceList.valueChanges.pipe(
        startWith(''),
        map( category => category ?  this._filterValue(category, this.choiceList, 'choiceList' ) : this.choiceList.slice())
     );
    });
   }
    /**/

  // Insert Question Data
  createQuestion() {
    if (this.createQuesForm.invalid) {
      return;
    } else {
      let inputQuestion : QuestionsModel; 
      inputQuestion= {
        genericText: this.createQuesForm.controls['genericText'].value,
        activeYn: (this.createQuesForm.controls['activeYn'].value == true) ? 'Y': 'N',
        percentileYn: (this.createQuesForm.controls['percentileYn'].value == true) ? 'Y': 'N',
        questionPosNegFlag: (this.createQuesForm.controls['questionPosNegFlag'].value == 'POSITIVIE') ? 'Y': 'N',
        summRptYn: (this.createQuesForm.controls['summRptYn'].value == true) ? 'Y': 'N',
        questionCategory: this.createQuesForm.controls['questionCategory'].value
      }
      console.log(inputQuestion);
      this.commonService.insert(this.url, inputQuestion)
      .subscribe((result) => {
        this.globalResponse = result;
      },
      error => {
        console.log('error', error.message);
        this.toastorService.warn('Error' + error.message);
      },
      () => {
        this.toastorService.success('Submitted Successfully');
      }
      );
      this.createQuestionRef.close();
      // tslint:disable-next-line:deprecation
      event.preventDefault();
    }
  }

  onCancel() {
    console.log('teest');
    this.createQuesForm.reset();
    // tslint:disable-next-line:deprecation
    event.preventDefault();
  }

}
