import {
  Component, OnInit, Output, EventEmitter, ViewChild,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Inject,
  OnDestroy
} from '@angular/core';
import { DateAdapter, MAT_DATE_FORMATS, MatDateFormats } from '@angular/material/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { MatCalendar, MatDatepicker, MatDatepickerInputEvent } from '@angular/material/datepicker';
import { MaterialModule } from '../../../../app.material.module';
@Component({
  // tslint:disable-next-line: component-selector
  selector: 'example-header',
  styles: [`
    .example-header {
      display: flex;
      align-items: center;
      padding: 0.1em;
    }

    .example-header-label {
      flex: 1;
      height: 1em;
      text-align: center;
    }

    .example-double-arrow .mat-icon {
      margin: -22%;
    }
  `],
  template: `
  <div class="example-header">
  <label>Start Date: </label><input [matDatepicker]="picker" 
  (dateInput)="firstDateInput($event)"
  [min]="minDate" 
  [max]="maxDate"
  [value]="minDate"
  placeholder="yyyy/MMM/dd">

</div>
<div class="example-header">
<label>End Date: </label><input [matDatepicker]="picker1" 
[min]="secondMinDate" 
[max]="maxDate"
[value]="maxDate"
placeholder="Choose a date">
</div>
    <div class="example-header">
      <span class="example-header-label">{{periodLabel}}</span>
      <button mat-icon-button (click)="previousClicked('month')">
        <mat-icon>keyboard_arrow_left</mat-icon>
      </button>
      <button mat-icon-button (click)="nextClicked('month')">
        <mat-icon>keyboard_arrow_right</mat-icon>
      </button>
    </div>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class QuestionCustomdatepickerComponent<D> implements OnDestroy {
  private questionDestroyed = new Subject<void>();
  minDate = new Date();
  maxDate = new Date();
  secondMinDate = this.minDate;
  @ViewChild('picker1', { static: true }) picker1: MatDatepicker<any>;
  constructor(
    private questioncalendar: MatCalendar<D>, private questiondateAdapter: DateAdapter<D>,
    @Inject(MAT_DATE_FORMATS) private questiondateFormats: MatDateFormats, cdr: ChangeDetectorRef) {
    questioncalendar.stateChanges
      .pipe(takeUntil(this.questionDestroyed))
      .subscribe(() => cdr.markForCheck());
  }

  ngOnDestroy() {
    this.questionDestroyed.next();
    this.questionDestroyed.complete();
  }

  get periodLabel() {
    return this.questiondateAdapter
      .format(this.questioncalendar.activeDate, this.questiondateFormats.display.monthYearLabel)
      .toLocaleUpperCase();
  }
  get startDate() {
    return this.questiondateAdapter
      .format(this.questioncalendar.activeDate, this.questiondateFormats.display.dateInput)
      .toLocaleUpperCase();
  }

  previousClicked(mode: 'month' | 'year') {
    this.questioncalendar.activeDate = mode === 'month' ?
      this.questiondateAdapter.addCalendarMonths(this.questioncalendar.activeDate, -1) :
      this.questiondateAdapter.addCalendarYears(this.questioncalendar.activeDate, -1);
  }

  nextClicked(mode: 'month' | 'year') {
    this.questioncalendar.activeDate = mode === 'month' ?
      this.questiondateAdapter.addCalendarMonths(this.questioncalendar.activeDate, 1) :
      this.questiondateAdapter.addCalendarYears(this.questioncalendar.activeDate, 1);
  }
  firstDateInput(event: MatDatepickerInputEvent<Date>): void {
    this.secondMinDate = event.value;
    this.picker1.open();
  }
}
