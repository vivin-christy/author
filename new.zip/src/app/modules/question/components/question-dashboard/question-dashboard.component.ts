import {
  Component, OnInit, Output, EventEmitter, ViewChild, ElementRef
} from '@angular/core';
import { AppConfig } from '../../../../app.config';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { QuestionService } from 'src/app/services/question.service';
import { MatTableDataSource } from '@angular/material/table';
import { QuestiondashboardDatatable } from '../../../../models/questiondashboard-datatable';
import { NotificationService } from 'src/app/services/notification.service';
import { CommonService } from 'src/app/services/common.service';
import { QuestiondashboardDatatableService } from 'src/app/services/questiondashboard-datatable.service';
import { QuestionsModel } from 'src/app/models/questions.model';
import { FormControl, FormGroup } from '@angular/forms';
import { QuestionCustomdatepickerComponent } from './question-customdatepicker.component';
import { QuestionSurveydialogComponent } from './question-surveydialog.component';
import { MatDatepickerInputEvent, MatDatepicker } from '@angular/material/datepicker';
import { MatDialog } from '@angular/material';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-question-dashboard',
  templateUrl: './question-dashboard.component.html',
  styleUrls: ['./question-dashboard.component.scss'],
  providers: [QuestiondashboardDatatableService]
})
export class QuestiondashboardComponent implements OnInit {
  @Output() editEvent = new EventEmitter();
  // tslint:disable-next-line: no-output-rename
  @Output('closed') closedStream: EventEmitter<void>;
  // tslint:disable-next-line: no-output-rename
  @Output('opened') openedStream: EventEmitter<void>;
  public globalResponse: any;
  appConstants = AppConfig.settings;
  questionConstants: any;
  dataTableHeader: any;
  dataTableColumns: any;
  dataTableFillterColumns: any;
  questionText: any;
  displayedFilterdataTableColumns: string[];
  dataTableSource: any = [];
  connotationControl = new FormControl();
  categoryControl = new FormControl();
  connotationList: any[];
  percentileList: any[];
  summaryReportList: any[];
  statusList: any[];
  categoryList: any;
  dataTableGrid: any = [];
  dataTableGrid1: any = [];
  public url = 'question';
  pipe: DatePipe;
  // public categoryControl: FormGroup;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  // @ViewChild('elementToFocus', { static: true }) _input: ElementRef;

  datepickerHeader = QuestionCustomdatepickerComponent;
  events: string[] = [];
  constructor(
    private appconfig: AppConfig,
    private commonService: CommonService,
    private toastorService: NotificationService,
    private questionservice: QuestiondashboardDatatableService,
    private surveyDialog: MatDialog, private quesService: QuestionService,
  ) {

    this.dataTableHeader = this.appConstants.questiondashboardHeader;
    this.dataTableColumns = Object.values(this.appConstants.questionDashboardTableColumns).slice();
    this.dataTableFillterColumns = Object.values(this.appConstants.questionDashboardFillterTableColumns);
    this.connotationList = Object.values(this.appConstants.connotationList);
    this.percentileList = Object.values(this.appConstants.percentileList);
    this.summaryReportList = Object.values(this.appConstants.summaryReportList);
    this.statusList = Object.values(this.appConstants.statusList);
    this.categoryList = this.categoryList,
      this.pipe = new DatePipe('en');
  }

  ngOnInit() {
    this.getquestion();
    this.getCategory();
    this.dataTableGrid.paginator = this.paginator;
    this.dataTableGrid.sort = this.sort;


  }
  getquestion() {
    this.questionservice.getQuestionDashboard()
      .subscribe(
        dataSource => {
          this.dataTableGrid = dataSource,
            this.dataTableSource = new MatTableDataSource<QuestiondashboardDatatable>(this.dataTableGrid.content),
            this.dataTableGrid = this.dataTableSource;
          console.log('Question DataTable', this.dataTableGrid);
          this.dataTableGrid.sort = this.sort;
        }
      );
  }

  setupFilter(column: string) {
    console.log('col ', column);
    this.dataTableGrid.filterPredicate = (d: QuestiondashboardDatatable, filter: string) => {
      const textToSearch = d[column] && d[column].toLowerCase() || '';
      return textToSearch.indexOf(filter) !== -1;
    };
  }

  applyFilter(filterValue: string) {
    console.log('filt', filterValue);
    this.dataTableGrid.filter = filterValue.trim().toLowerCase();
  }


  startEdit(data: any) {
    console.log(data.questionCategoryDesc);
    let inputQuestion: any;
    inputQuestion = {
      questionLibraryId: data.questionLibraryId,
      genericText: data.genericText,
      activeYn: (data.activeYn === 'Y') ? true : false,
      percentileYn: (data.percentileYn === 'Y') ? true : false,
      questionPosNegFlag: (data.questionPosNegFlag === 'Y') ? 'POSITIVE' : (data.questionPosNegFlag === 'N') ? 'NEGATIVE' : 'OTHERS',
      summRptYn: (data.summRptYn === 'Y') ? true : false,
      questionCategory: {
        questionCategoryId: data.questionCategoryId,
        questionCategoryDesc: data.questionCategoryDesc
      }
    };
    this.editEvent.emit(inputQuestion);
    this.reload();
  }
  reload() {
    this.getquestion();

  }
  getCategory(): void {
    this.quesService.getCategoryList().subscribe(data => {
      this.categoryList = data;
      console.log(this.categoryList)
    });
  }

  openDialog(row: any) {
    console.log('Row clicked', row);
    this.questionservice.getSurveyTable(row).subscribe(res => {
      console.log(res)
      const dialog = this.surveyDialog.open(QuestionSurveydialogComponent, {
        // Can be closed only by clicking the close button

        disableClose: true,
        data: res,
        panelClass: 'surveyModal'

      });
    })


  }

  questionOpenCalendarClosed(picker: MatDatepicker<Date>) {
    picker.open();

    console.log('here2', picker._selected);
    /** picker.closed(); */
    /** setTimeout(() => this._input.nativeElement.focus()); */
  }


  _openCalendar(picker: MatDatepicker<Date>) {
    // picker.open();
    /** setTimeout(() => this._input.nativeElement.focus()); */
  }

  _closeCalendar(picker: MatDatepicker<Date>) {
    // picker.open();
    /** setTimeout(() => this._input.nativeElement.focus()); */
  }

  getDates(range, column) {
    //const fromDate =  datepipe.transform(range.start, 'dd/MM/yyyy');//range.start
    const fromDate = this.pipe.transform(range.start, 'yyyy-MM-dd'); // '2001-07-07T11:39:24.000+0000';//range.start
    const toDate = this.pipe.transform(range.end, 'yyyy-MM-dd'); // '2001-08-08T11:39:24.000+0000'; //range.end
    
    if (column === 'createdDt') {
      console.log('testDate 11', fromDate, toDate, column);
      this.dataTableGrid.data = this.dataTableGrid.data.filter(e => e.createdDt > fromDate && e.createdDt < toDate);
    } else {
      
      console.log('testDate 11', fromDate, toDate, column);
      this.dataTableGrid.data = this.dataTableGrid.data.filter(e => e.lastUpdatedDt > fromDate && e.lastUpdatedDt < toDate);
    }
    console.log('data', this.dataTableGrid.data);
  }
}


