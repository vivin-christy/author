import {
  Component, OnInit, Output, EventEmitter, ViewChild, ElementRef
} from '@angular/core';
import { AppConfig } from '../../../../app.config';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { QuestionService } from 'src/app/services/question.service';
import { MatTableDataSource } from '@angular/material/table';
import { QuestiondashboardDatatable } from '../../../../models/questiondashboard-datatable';
import { NotificationService } from 'src/app/services/notification.service';
import { CommonService } from 'src/app/services/common.service';
import { QuestiondashboardDatatableService } from 'src/app/services/questiondashboard-datatable.service';
import { QuestionsModel } from 'src/app/models/questions.model';
import { FormControl } from '@angular/forms';

import { QuestionCustomdatepickerComponent } from './question-customdatepicker.component';
import { QuestionSurveydialogComponent } from './question-surveydialog.component';

import { MatDatepickerInputEvent, MatDatepicker } from '@angular/material/datepicker';
import {
  CdkVirtualScrollViewport,
  FixedSizeVirtualScrollStrategy,
  VIRTUAL_SCROLL_STRATEGY
} from '@angular/cdk/scrolling';
import { DataSource } from '@angular/cdk/collections';
import { BehaviorSubject, Observable } from 'rxjs';
import { MatDialog } from '@angular/material';
const PAGESIZE = 20;
const ROW_HEIGHT = 8;
export class GridTableDataSource extends DataSource<any> {
  private dataTable: any[];
  get allData(): any[] {
    return this.dataTable.slice();
  }

  set allData(data: any[]) {
    this.dataTable = data;
    this.viewport.scrollToOffset(0);
    this.viewport.setTotalContentSize(this.itemSize * data.length);
    this.visibleData.next(this.dataTable.slice(0, PAGESIZE));
  }

  offset = 0;
  offsetChange = new BehaviorSubject(0);
  constructor(initialData: any[], private viewport: CdkVirtualScrollViewport, private itemSize: number) {
    super();
    this.dataTable = initialData;
    this.viewport.elementScrolled().subscribe((ev: any) => {
      const start = Math.floor(ev.currentTarget.scrollTop / ROW_HEIGHT);
      const prevExtraData = start > 5 ? 5 : 0;
      // const prevExtraData = 0;
      const slicedData = this.dataTable.slice(start - prevExtraData, start + (PAGESIZE - prevExtraData));
      this.offset = ROW_HEIGHT * (start - prevExtraData);
      this.viewport.setRenderedContentOffset(this.offset);
      this.offsetChange.next(this.offset);
      this.visibleData.next(slicedData);
    });
  }

  private readonly visibleData: BehaviorSubject<any[]> = new BehaviorSubject([]);

  connect(collectionViewer: import('@angular/cdk/collections').CollectionViewer): Observable<any[] | ReadonlyArray<any>> {
    return this.visibleData;
  }

  disconnect(collectionViewer: import('@angular/cdk/collections').CollectionViewer): void {
  }
}

export class CustomVirtualScrollStrategy extends FixedSizeVirtualScrollStrategy {
  constructor() {
    super(ROW_HEIGHT, 1000, 2000);
  }

  attach(viewport: CdkVirtualScrollViewport): void {
    this.onDataLengthChanged();
  }
}





@Component({
  selector: 'app-question-dashboard',
  templateUrl: './question-dashboard.component.html',
  styleUrls: ['./question-dashboard.component.scss'],
  providers: [QuestiondashboardDatatableService, { provide: VIRTUAL_SCROLL_STRATEGY, useClass: CustomVirtualScrollStrategy }]
})
export class QuestiondashboardComponent implements OnInit {
  @Output() editEvent = new EventEmitter();
  @Output() surveyEvent = new EventEmitter();
  // tslint:disable-next-line: no-output-rename
  @Output('closed') closedStream: EventEmitter<void>;
  // tslint:disable-next-line: no-output-rename
  @Output('opened') openedStream: EventEmitter<void>;
  public globalResponse: any;
  appConstants = AppConfig.settings;
  questionConstants: any;
  dataTableHeader: any;
  dataTableColumns: any;
  dataTableFillterColumns: any;
  questionText: any;
  displayedFilterdataTableColumns: string[];
  dataTableSource: any = [];
  connotationControl = new FormControl();
  categoryControl = new FormControl();
  connotationList: any[];
  percentileList: any[];
  summaryReportList: any[];
  statusList: any[];
  categoryList: any[];
  dataTableGrid: any = [];
  dataTableGrid1: any = [];
  surveyId: any;
  public url = 'question';
  placeholderHeight = 0;
  dataSource: GridTableDataSource;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild('elementToFocus', { static: true }) _input: ElementRef;
  datepickerHeader = QuestionCustomdatepickerComponent;
  itemSize = 8;
  @ViewChild(CdkVirtualScrollViewport, { static: true }) viewport: CdkVirtualScrollViewport;
  events: string[] = [];
  constructor(
    private appconfig: AppConfig,
    private commonService: CommonService,
    private toastorService: NotificationService,
    private questionservice: QuestiondashboardDatatableService,
    private surveyDialog: MatDialog
  ) {

    this.dataTableHeader = this.appConstants.questiondashboardHeader;
    this.dataTableColumns = Object.values(this.appConstants.questionDashboardTableColumns).slice();
    this.dataTableFillterColumns = Object.values(this.appConstants.questionDashboardFillterTableColumns);
    this.connotationList = Object.values(this.appConstants.connotationList);
    this.percentileList = Object.values(this.appConstants.percentileList);
    this.summaryReportList = Object.values(this.appConstants.summaryReportList);
    this.statusList = Object.values(this.appConstants.statusList);
    this.categoryList = Object.values(this.appConstants.categoryList);
  }

  ngOnInit() {
    this.getquestion();
    this.dataTableGrid.paginator = this.paginator;
    this.dataTableGrid.sort = this.sort;
  }
  getquestion() {
    this.questionservice.getQuestionDashboard()
      .subscribe(
        dataSource => {
          this.dataTableGrid1 = dataSource,
            //this.dataTableSource = new MatTableDataSource<QuestiondashboardDatatable>(this.dataTableGrid.content),
            //this.dataTableGrid = this.dataTableSource;
            //console.log('source', this.dataTableGrid);
            //this.dataTableGrid.sort = this.sort;

            this.dataTableGrid = new GridTableDataSource(this.dataTableGrid1.content, this.viewport, this.itemSize);
          console.log('source', this.dataTableGrid);
          this.dataTableGrid.offsetChange.subscribe(offset => {
            this.placeholderHeight = offset;
          });
          this.dataTableGrid.allData = this.dataTableGrid1.content;
        }
      );
  }
  placeholderWhen(index: number, _: any) {
    return index === 0;
  }
  setupFilter(column: string) {
    console.log(column);
    this.dataTableGrid.filterPredicate = (d: QuestiondashboardDatatable, filter: string) => {
      const textToSearch = d[column] && d[column].toLowerCase() || '';
      return textToSearch.indexOf(filter) !== -1;
    };
  }

  applyFilter(filterValue: string) {
    console.log(filterValue);
    this.dataTableGrid.filter = filterValue.trim().toLowerCase();
  }

  startEdit(data: QuestionsModel) {
    console.log(data);
    let inputQuestion: any;
    inputQuestion = {
      questionLibraryId: data.questionLibraryId,
      genericText: data.genericText,
      activeYn: (data.activeYn === 'Y') ? true : false,
      percentileYn: (data.percentileYn === 'Y') ? true : false,
      questionPosNegFlag: (data.questionPosNegFlag === 'Y') ? 'POSITIVE' : (data.questionPosNegFlag === 'N') ? 'NEGATIVE' : 'OTHERS',
      summRptYn: (data.summRptYn === 'Y') ? true : false,
      questionCategory: {
        questionCategoryId: data.questionCategory.questionCategoryId,
        questionCategoryDesc: data.questionCategory.questionCategoryDesc
      }
    };
    this.editEvent.emit(inputQuestion);
    this.reload();
  }
  reload() {
    this.getquestion();

  }


  openDialog(row: any) {
    console.log('Row clicked', row);
    const dialog = this.surveyDialog.open(QuestionSurveydialogComponent, {
      width: '250px',
      // Can be closed only by clicking the close button
      disableClose: true,
      data: row
    });
  }

  questionOpenCalendarClosed(picker: MatDatepicker<Date>) {
    picker.open();

    console.log('here2', picker._selected);
    /** picker.closed(); */
    /** setTimeout(() => this._input.nativeElement.focus()); */
  }


  _openCalendar(picker: MatDatepicker<Date>) {
    // picker.open();
    /** setTimeout(() => this._input.nativeElement.focus()); */
  }

  _closeCalendar(picker: MatDatepicker<Date>) {
    // picker.open();
    /** setTimeout(() => this._input.nativeElement.focus()); */
  }

}


