import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { QuestiondashboardComponent } from './components/question-dashboard/question-dashboard.component';
import { QuestionCustomdatepickerComponent } from './components/question-dashboard/question-customdatepicker.component';
import { QuestionRoutingModule } from './question.routing.module';
import { QuestionComponent } from './layout/question.component';
import { CreatequestionComponent } from './components/create-question/create-question.component';
import { AppSingletonService } from '../../app.singleton.service';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MaterialModule } from 'src/app/app.material.module';
import { EditQuestionComponent } from './components/edit-question/edit-question.component';
import { QuestionSurveydialogComponent } from './components/question-dashboard/question-surveydialog.component';
import { SharedModule } from 'src/app/shared';

@NgModule({
  declarations: [
    QuestiondashboardComponent,
    QuestionCustomdatepickerComponent,
    QuestionComponent,
    CreatequestionComponent,
    EditQuestionComponent,
    QuestionSurveydialogComponent
  ],
  imports: [
    CommonModule,
    QuestionRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
    SharedModule
  ],
  providers: [QuestiondashboardComponent],
  entryComponents: [
    QuestiondashboardComponent,
    QuestionCustomdatepickerComponent,
    QuestionComponent,
    CreatequestionComponent,
    EditQuestionComponent,
    QuestionSurveydialogComponent]
})
export class QuestionModule { }
