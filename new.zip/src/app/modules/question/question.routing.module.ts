import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { QuestionComponent } from './layout/question.component';

const questionRouting: Routes  = [
  {
    path: 'question',
    component: QuestionComponent
  },
  { path: '', redirectTo: 'question', pathMatch: 'full' }
];


@NgModule({
  imports: [RouterModule.forChild(questionRouting)  ],
  exports: [RouterModule]
})
export class QuestionRoutingModule { }
