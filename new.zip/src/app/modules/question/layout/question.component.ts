import { Component, OnInit, ViewChild } from '@angular/core';
import { AppSingletonService } from '../../../app.singleton.service';

import { CreatequestionComponent } from '../components/create-question/create-question.component';
import { EditQuestionComponent } from '../components/edit-question/edit-question.component';
import { MatDialog } from '@angular/material/dialog';
import { QuestiondashboardComponent } from '../components/question-dashboard/question-dashboard.component';
//import { SurveyPopComponent } from '../components/survey-pop111/survey-pop.component';
import { AppConfig } from '../../../app.config';
import { CommonService } from 'src/app/services/common.service';
import { NotificationService } from 'src/app/services/notification.service';

@Component({
  selector: 'app-question',
  templateUrl: './question.component.html',
  styleUrls: ['./question.component.scss']
})
export class QuestionComponent implements OnInit {

  @ViewChild(QuestiondashboardComponent, { static: false }) private dashboard: QuestiondashboardComponent;
  appConstants = AppConfig.settings;
  dashboardTitle:string;
  createText:string;
  dialogRef:any;

  constructor(
    private singletonservice: AppSingletonService, public dialog: MatDialog, private appconfig: AppConfig,
    private commonService: CommonService,
    private toastorService: NotificationService
  ) {
	this.dashboardTitle = this.appConstants.questiontitle;
	this.createText = this.appConstants.questionCreateText;
  }

  ngOnInit() {
  }

  // Open Dialog for Create Questiions
  openCreateQuestion(): void {
    this.dialogRef = this.dialog.open((CreatequestionComponent), { panelClass: 'newQuestion', disableClose: true});
    //let CreatequestionComponent = { hasBackdrop: false, skipHide: true, panelClass: 'cssthemeInfo', width: '300px', height: '400px' };

    this.dialogRef.afterClosed().subscribe(result => this.dashboard.getquestion());
  }
  
  // Open Dialog for Edit Questiions
  editForm(data: any) {    this.dialogRef = this.dialog.open(EditQuestionComponent, { data , panelClass: 'newQuestion', disableClose: true});

    this.dialogRef.afterClosed().subscribe(result => this.dashboard.getquestion());
  }
  
  // Export Excel 
exportExcel(){
  this.commonService.exportExcel('questions/download', 'Question').subscribe(
    (res)=> {
      this.downLoadFile(res);
      this.toastorService.success(res.filename+" excel generated  successfully");
      },
      error => {
        this.toastorService.warn('Error' + error.message);
      }
  );
  }

  // Download files 
  downLoadFile(data){
    const element = document.createElement('a');
    element.href = URL.createObjectURL(data.fileContent);
    element.download = data.filename;
    document.body.appendChild(element);
    element.click();
  }


}
