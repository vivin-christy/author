import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedListComponent } from './layout/shared-list.component';
import { SharedListDashboardComponent } from './components/shared-list-dashboard/shared-list-dashboard.component';
import { SharedlistRoutingModule } from './sharedlist.routing.module';
import { MaterialModule } from 'src/app/app.material.module';
import { SharedListSidenavComponent } from './components/shared-list-sidenav/shared-list-sidenav.component';
import { SharedModule } from 'src/app/shared';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CreateSharedChoiceComponent } from './components/create-shared-choice/create-shared-choice.component';

@NgModule({
  declarations: [
    SharedListComponent,
     SharedListDashboardComponent, 
     SharedListSidenavComponent,
     CreateSharedChoiceComponent
    ],
  imports: [
    CommonModule,
    SharedlistRoutingModule,
    MaterialModule,
    ReactiveFormsModule,
    FormsModule,
    SharedlistRoutingModule,
    SharedModule
  ],
  entryComponents: [SharedListComponent,
    SharedListDashboardComponent, 
    SharedListSidenavComponent,
    CreateSharedChoiceComponent
    ]
})
export class SharedlistModule { }
