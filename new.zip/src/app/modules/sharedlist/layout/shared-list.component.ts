import { Component, OnInit } from '@angular/core';
import { AppConfig } from 'src/app/app.config';
import { MatDialog } from '@angular/material';
import { CreateSharedChoiceComponent } from '../components/create-shared-choice/create-shared-choice.component';

@Component({
  selector: 'app-shared-list',
  templateUrl: './shared-list.component.html',
  styleUrls: ['./shared-list.component.scss']
})
export class SharedListComponent implements OnInit {
  appConstants = AppConfig.settings;
  dashboardTitle: string;
  sharedQuestionCreate:string;
  sharedChoiceCreate: string;
  sharedEdit:string;
  dialogRef:any;
  template:any[]; // = false;
  constructor(private appconfig: AppConfig,public dialog: MatDialog) { 

    this.dashboardTitle = this.appConstants.SharedListTitle;
    this.sharedQuestionCreate = this.appConstants.SharedQuestionCreate;
    this.sharedChoiceCreate = this.appConstants.SharedChoiceCreate;
    this.sharedEdit=this.appConstants.SharedEdit;
  }

  ngOnInit() {
  }

  openCreateSharedChoice(){
    this.dialogRef = this.dialog.open((CreateSharedChoiceComponent), { panelClass: 'newQuestion', disableClose: true});
    //let CreatequestionComponent = { hasBackdrop: false, skipHide: true, panelClass: 'cssthemeInfo', width: '300px', height: '400px' };

    this.dialogRef.afterClosed();

  }

  
public displayTemplate(event):void {
  console.log('testt',event );
  /*
  if(event[0].type=='sharedQuestions'){
    this.template = true;
    console.log('testt',event );
  } else {
    this.template = false;
  }
  */
 this.template= event;
}

}
