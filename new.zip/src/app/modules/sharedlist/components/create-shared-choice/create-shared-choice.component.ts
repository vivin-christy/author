import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MatDialogRef } from '@angular/material';
import { SharedListDashboardComponent } from '../shared-list-dashboard/shared-list-dashboard.component';
import { AppConfig } from 'src/app/app.config';
import { SharedlistService } from 'src/app/services/sharedlist.service';
@Component({
  selector: 'app-create-shared-choice',
  templateUrl: './create-shared-choice.component.html',
  styleUrls: ['./create-shared-choice.component.scss'],
  providers:[SharedlistService]
})
export class CreateSharedChoiceComponent implements OnInit {
  shareQuestionList:any[] = [  {"id": 1, "value1": "TONIGHT SHOW WITH JAY LENO"},
{"id": 2, "value1": "PAN AM VIEWERS"},
{"id": 3, "value1": "FAIRLY LEGAL VIEWERS"},
{"id": 1, "value1": "TONIGHT SHOW WITH JAY LENO"},
{"id": 2, "value1": "PAN AM VIEWERS"},
{"id": 3, "value1": "FAIRLY LEGAL VIEWERS"},
{"id": 1, "value1": "TONIGHT SHOW WITH JAY LENO"},
{"id": 2, "value1": "PAN AM VIEWERS"},
{"id": 3, "value1": "FAIRLY LEGAL VIEWERS"} ];

  appConstants = AppConfig.settings;
  createSharedChoiceForm: FormGroup;
  sharedChoiceCreateLabel: any;
  validationMsg: any;
  searchQModel :string;
  public searchChoiModel:string;
  
  constructor(private createChoiceRef: MatDialogRef<SharedListDashboardComponent>,private sharedlistService: SharedlistService ) {
this.sharedChoiceCreateLabel=this.appConstants.SharedChoiceModel;
this.validationMsg=this.appConstants.validationMsg;
this.getSharedQuestionsList();

   }

  ngOnInit() {
    this.createSharedChoiceForm = new FormGroup({
      sharedChoiceName: new FormControl('', [Validators.required]),
      sharedChoiceDesc: new FormControl('', [Validators.required]),
      sharedChoiceList: new FormControl('')
    });

  }
  data=[];
  getSharedQuestionsList(){
    this.sharedlistService.getSharedQuestions().subscribe(data => 
      {
        console.log('before', data);
        this.shareQuestionList = data.map(item => {
          return {
            id: item.id,
            value: item.value1
          };
        })
        console.log('test', this.shareQuestionList);
      }
    );}
    public searchInput(input: any, type: string):void {
      if(type === 'sharedQuestions'){
       
        this.searchChoiModel = input;
      }
    }
  
  public hasError = (controlName: string, errorName: string) => {
    return this.createSharedChoiceForm.controls[controlName].hasError(errorName);
  }

}
