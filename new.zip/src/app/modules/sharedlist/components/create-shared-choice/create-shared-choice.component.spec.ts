import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateSharedChoiceComponent } from './create-shared-choice.component';

describe('CreateSharedChoiceComponent', () => {
  let component: CreateSharedChoiceComponent;
  let fixture: ComponentFixture<CreateSharedChoiceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateSharedChoiceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateSharedChoiceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
