import { Component, OnInit, Output, EventEmitter, ViewChild, ElementRef, Input } from '@angular/core';
import { AppConfig } from '../../../../app.config';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { FormControl, FormGroup } from '@angular/forms';
import { MatDatepickerInputEvent, MatDatepicker } from '@angular/material/datepicker';
import { MatDialog } from '@angular/material';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-shared-list-dashboard',
  templateUrl: './shared-list-dashboard.component.html',
  styleUrls: ['./shared-list-dashboard.component.scss']
})
export class SharedListDashboardComponent implements OnInit {
  @Output() editEvent = new EventEmitter();
  // tslint:disable-next-line: no-output-rename
  @Output('closed') closedStream: EventEmitter<void>;
  // tslint:disable-next-line: no-output-rename
  @Output('opened') openedStream: EventEmitter<void>;
  public globalResponse: any;
  appConstants = AppConfig.settings;
  questionConstants: any;
  dataTableHeader: any;
  dataTableColumns: any;
  dataTableFillterColumns: any;
  questionText: any;
  displayedFilterdataTableColumns: string[];
  dataTableSource: any = [];
  connotationControl = new FormControl();
  categoryControl = new FormControl();
  connotationList: any[];
  percentileList: any[];
  summaryReportList: any[];
  statusList: any[];
  categoryList: any;
  dataTableGrid: any = [];
  dataTableGrid1: any = [];
  public url = 'question';
  pipe: DatePipe;
  // public categoryControl: FormGroup;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  // @ViewChild('elementToFocus', { static: true }) _input: ElementRef;
  @Input() templateInput;
  constructor() { }

  ngOnInit() {
  }

  

}
