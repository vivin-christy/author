import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SharedListDashboardComponent } from './shared-list-dashboard.component';

describe('SharedListDashboardComponent', () => {
  let component: SharedListDashboardComponent;
  let fixture: ComponentFixture<SharedListDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SharedListDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SharedListDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
