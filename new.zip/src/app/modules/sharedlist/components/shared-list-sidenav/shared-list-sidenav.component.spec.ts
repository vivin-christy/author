import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SharedListSidenavComponent } from './shared-list-sidenav.component';

describe('SharedListSidenavComponent', () => {
  let component: SharedListSidenavComponent;
  let fixture: ComponentFixture<SharedListSidenavComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SharedListSidenavComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SharedListSidenavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
