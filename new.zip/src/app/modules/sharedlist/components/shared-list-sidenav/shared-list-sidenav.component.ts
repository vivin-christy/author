import { Component, OnInit, Input,EventEmitter, Output } from '@angular/core';
import { SharedlistService } from 'src/app/services/sharedlist.service';
import { List } from 'src/app/models/list.model';
@Component({
  selector: 'app-shared-list-sidenav',
  templateUrl: './shared-list-sidenav.component.html',
  styleUrls: ['./shared-list-sidenav.component.scss'],
  providers:[SharedlistService]
})
export class SharedListSidenavComponent implements OnInit{

shareQuestionList:any[] = [  {"id": 1, "value1": "TONIGHT SHOW WITH JAY LENO"},
{"id": 2, "value1": "PAN AM VIEWERS"},
{"id": 3, "value1": "FAIRLY LEGAL VIEWERS"},
{"id": 1, "value1": "TONIGHT SHOW WITH JAY LENO"},
{"id": 2, "value1": "PAN AM VIEWERS"},
{"id": 3, "value1": "FAIRLY LEGAL VIEWERS"},
{"id": 1, "value1": "TONIGHT SHOW WITH JAY LENO"},
{"id": 2, "value1": "PAN AM VIEWERS"},
{"id": 3, "value1": "FAIRLY LEGAL VIEWERS"} ];


public currentContact: any;
public searchQuesModel:string;
public searchChoiModel:string;
public searchVarModel:string;
searchQModel :string;


@Output() public select: EventEmitter<{}> = new EventEmitter();

constructor( private sharedlistService: SharedlistService  ) { 
  this.getSharedQuestionsList();
}

ngOnInit(){
}

data=[];
getSharedQuestionsList(){
  this.sharedlistService.getSharedQuestions().subscribe(data => 
    {
      console.log('before', data);
      this.shareQuestionList = data.map(item => {
        return {
          id: item.id,
          value: item.value1
        };
      })
      console.log('test', this.shareQuestionList);
    }
  );
  
  /*
  arrayObj = arrayObj.map(item => {
    return {
      value: item.key1,
      key2: item.key2
    };
  });*/

  
}

public searchInput(input: any, type: string):void {
  if(type === 'sharedQuestions'){
    this.searchQuesModel = input;
  } else {
    this.searchChoiModel = input;
  }
}
public onSelect(type:string, id:any){
  console.log('test', type);
  this.data = [{
    type: type,
    id: id}]
  this.select.emit(this.data);
}

}