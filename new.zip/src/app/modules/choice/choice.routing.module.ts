import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ChoiceLayoutComponent } from './layout/choice-layout.component';



const choiceRouting: Routes = [
  { path: '', component: ChoiceLayoutComponent, pathMatch: 'full' }
];


@NgModule({
  imports: [RouterModule.forChild(choiceRouting)],
  exports: [RouterModule]
})
export class ChoiceRoutingModule { }
