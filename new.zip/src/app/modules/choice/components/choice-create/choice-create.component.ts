import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { ChoiceDashboardComponent } from '../choice-dashboard/choice-dashboard.component';
import { NotificationService } from 'src/app/services/notification.service';
import { CommonService } from 'src/app/services/common.service';
import { ChoiceService } from 'src/app/services/choice.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AppConfig }  from '../../../../app.config';
import { Observable } from 'rxjs';
import { List, sharedList } from 'src/app/models/list.model';
import { startWith, map } from 'rxjs/operators';
import { ChoicedashboardDatatable } from 'src/app/models/choicedashboard-datatable';

@Component({
  selector: 'app-choice-create',
  templateUrl: './choice-create.component.html',
  styleUrls: ['./choice-create.component.scss']
})
export class ChoiceCreateComponent implements OnInit {
  appConstants = AppConfig.settings;
  choiceCreateLabel: any;
  validationMsg: any;
  createChoiceForm: FormGroup;
  public globalResponse: any;
  public url = 'choices';
  filteredSharedList: Observable<sharedList[]>;
  constructor(
    private createChoiceRef: MatDialogRef<ChoiceDashboardComponent>,
    private choiceService: ChoiceService,
    private toastorService: NotificationService,
    private commonService: CommonService
  ) {
    this.choiceCreateLabel = this.appConstants.choiceModel;
    this.validationMsg = this.appConstants.validationMsg;
  }
  sharedList: sharedList[]=  [
    {'sharedListId': 1, 'sharedListDesc': 'Value'},
    {'sharedListId': 2, 'sharedListDesc': 'sdfsd'}
  ];
  
  ngOnInit() {
    this.getSharedList();
    this.createChoiceForm = new FormGroup({
     choiceName: new FormControl('', [Validators.required]),
     choiceLibraryDesc: new FormControl('', [Validators.required]),
     posNegFlag: new FormControl(true),
     activeYn: new FormControl(true),
     sharedList: new FormControl('')
   });
  }

  
// Validation Error Message
public hasError = (controlName: string, errorName: string) => {
  return this.createChoiceForm.controls[controlName].hasError(errorName);
}

// Set Slider field value
onChange(controlName: string, e) {
  if (e.checked === true) {
    this.createChoiceForm.controls[controlName].setValue(true);
  } else {
    this.createChoiceForm.controls[controlName].setValue(false);
  }
}


  //Close Popup
  close(event: MouseEvent): void {
    this.createChoiceRef.close();
    event.preventDefault();
  }

  initializeFormGroup() {
    console.log('inizialse');
    this.createChoiceForm.setValue({
      choiceName: '',
      choiceLibraryDesc: '',
      posNegFlag: true,
      activeYn: true,
      sharedList: ''
    });
  }

  //Shared List API
  getSharedList(): void {
    this.choiceService.getSharedList().subscribe(data => {
      //this.sharedList = data;
      this.filteredSharedList = this.createChoiceForm.controls.sharedList.valueChanges.pipe(
        startWith(''),
        map(shared => shared ? this._filterValue(shared, this.sharedList, 'sharedList'): this.sharedList.slice())
      )
    })
  }

  _filterValue(val: any, ArrList: any, Type:any) {
      const name = val.sharedListDesc || val; // val can be List or string
      const list = ArrList.filter(
        option => option.sharedListDesc.toLowerCase().indexOf(name.toLowerCase()) === 0 );
      return list;
  }
  sharedDisplayFn(filterBy): string {
    return filterBy ? filterBy.sharedListDesc : filterBy;
  }
  
  // Insert Question Data
  createChoice() {
    if (this.createChoiceForm.invalid) {
      return;
    } else {
      let inputChoice : ChoicedashboardDatatable; 
      inputChoice= {
        //choiceName: this.createChoiceForm.controls['choiceName'].value,
        choiceLibraryDesc: this.createChoiceForm.controls['choiceLibraryDesc'].value,
        posNegFlag: (this.createChoiceForm.controls['posNegFlag'].value == true) ? 'Y': 'N',
        activeYn: (this.createChoiceForm.controls['activeYn'].value == true) ? 'Y': 'N',
        sharedList: this.createChoiceForm.controls['sharedList'].value,
      }
      console.log('input Choice ',inputChoice);
      this.commonService.insert(this.url, inputChoice)
      .subscribe((result) => {
        this.globalResponse = result;
      },
      error => {
        console.log('error', error.message);
        this.toastorService.warn('Error' + error.message);
      },
      () => {
        this.toastorService.success('Submitted Successfully');
      }
      );
      this.createChoiceRef.close();
      // tslint:disable-next-line:deprecation
      event.preventDefault();
    }
  }



}
