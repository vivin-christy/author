import { Component, OnInit, Inject } from '@angular/core';
import { ChoiceDashboardComponent } from '../choice-dashboard/choice-dashboard.component';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ChoiceService } from 'src/app/services/choice.service';
import { NotificationService } from 'src/app/services/notification.service';
import { CommonService } from 'src/app/services/common.service';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import {AppConfig} from '../../../../app.config';
import { Observable } from 'rxjs';
import { sharedList } from 'src/app/models/list.model';
import { startWith, map } from 'rxjs/operators';
import { ChoicedashboardDatatable } from 'src/app/models/choicedashboard-datatable';

@Component({
  selector: 'app-choice-edit',
  templateUrl: './choice-edit.component.html',
  styleUrls: ['./choice-edit.component.scss']
})
export class ChoiceEditComponent implements OnInit {

  appConstants = AppConfig.settings;
  choiceCreateLabel: any;
  validationMsg: any;
  editChoiceForm: FormGroup;
  globalResponse: any;
  constructor(
    private appconfig: AppConfig,
    private editChoiceRef: MatDialogRef<ChoiceDashboardComponent>,
    private choiceService: ChoiceService,
    private toastorService: NotificationService,
    private commonService: CommonService,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.choiceCreateLabel = AppConfig.settings.choiceModel;
    this.validationMsg = AppConfig.settings.validationMsg;
  }
 
  public url = 'choices';
filteredSharedList: Observable<sharedList[]>;
sharedList: sharedList[]=  [
  {'sharedListId': 1, 'sharedListDesc': 'Value'},
  {'sharedListId': 2, 'sharedListDesc': 'sdfsd'}
];

ngOnInit() {
  this.getSharedList();
  this.editChoiceForm = new FormGroup({
   choiceLibraryId: new FormControl(null),
   choiceName: new FormControl('', [Validators.required]),
   choiceLibraryDesc: new FormControl('', [Validators.required]),
   posNegFlag: new FormControl(true),
   activeYn: new FormControl(true),
   sharedList: new FormControl('')
 });
}


// Validation Error Message
public hasError = (controlName: string, errorName: string) => {
return this.editChoiceForm.controls[controlName].hasError(errorName);
}

// Set Slider field value
onChange(controlName: string, e) {
if (e.checked === true) {
  this.editChoiceForm.controls[controlName].setValue(true);
} else {
  this.editChoiceForm.controls[controlName].setValue(false);
}
}


//Close Popup
close(event: MouseEvent): void {
  this.editChoiceRef.close();
  event.preventDefault();
}

initializeFormGroup() {
  console.log('inizialse');
  this.editChoiceForm.setValue({
    choiceLibraryId: '',
    choiceName: '',
    choiceLibraryDesc: '',
    posNegFlag: true,
    activeYn: true,
    sharedList: ''
  });
}

//Shared List API
getSharedList(): void {
  this.choiceService.getSharedList().subscribe(data => {
    //this.sharedList = data;
    this.filteredSharedList = this.editChoiceForm.controls.sharedList.valueChanges.pipe(
      startWith(''),
      map(shared => shared ? this._filterValue(shared, this.sharedList, 'sharedList'): this.sharedList.slice())
    )
  })
}

_filterValue(val: any, ArrList: any, Type:any) {
    const name = val.sharedListDesc || val; // val can be List or string
    const list = ArrList.filter(
      option => option.sharedListDesc.toLowerCase().indexOf(name.toLowerCase()) === 0 );
    return list;
}
sharedDisplayFn(filterBy): string {
  return filterBy ? filterBy.sharedListDesc : filterBy;
}


  // Update Choice
  updateChoice() {
     let inputChoice : ChoicedashboardDatatable; 
     inputChoice = {
      choiceLibraryId: this.editChoiceForm.controls['choiceLibraryId'].value,
     // choiceName: this.editChoiceForm.controls['choiceName'].value,
      choiceLibraryDesc: this.editChoiceForm.controls['choiceLibraryDesc'].value,
      posNegFlag: (this.editChoiceForm.controls['posNegFlag'].value == true) ? 'Y': 'N',
      activeYn: (this.editChoiceForm.controls['activeYn'].value == true) ? 'Y': 'N',
    //  sharedList: this.editChoiceForm.controls['sharedList'].value
    };
    console.log('choice',inputChoice );
    this.commonService.update( this.url, inputChoice).subscribe((result) => {
      this.globalResponse = result;
    },
    error => {
      console.log('error', error.message);
      this.toastorService.warn('Error' + error.message);
    },
    () => {
      this.toastorService.success('Submitted Successfully');
    });
    this.editChoiceRef.close();
  }


}