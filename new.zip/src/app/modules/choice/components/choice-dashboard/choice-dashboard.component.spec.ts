import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChoiceDashboardComponent } from './choice-dashboard.component';

describe('ChoiceDashboardComponent', () => {
  let component: ChoiceDashboardComponent;
  let fixture: ComponentFixture<ChoiceDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChoiceDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChoiceDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
