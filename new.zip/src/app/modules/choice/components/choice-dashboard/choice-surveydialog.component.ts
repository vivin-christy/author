import { Component, OnInit, Inject, Optional } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { AppConfig } from 'src/app/app.config';
import { SurveyTable } from 'src/app/models/survey.model';
import { MatTableDataSource } from '@angular/material';
@Component({
  selector: 'app-question-surveydialog',
  templateUrl: './choice-surveydialog.component.html',
  styles: [`
  .cdk-overlay-container .cdk-global-overlay-wrapper .cdk-overlay-pane .mat-dialog-container .question-dialog-container {
    /* right: 0; */
    /* top: 65px; */
    /* height: 100%; */
    position: absolute !important;
    width: 31%;
}`]
})
export class ChoiceSurveydialogComponent implements OnInit {
  appConstants = AppConfig.settings;
  surveyHeader: any;
  surveyColumns: any;
  surveyTableSource: any;
  constructor(
    public dialogRef: MatDialogRef<ChoiceSurveydialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
  ) {
    this.surveyHeader = this.appConstants.surveyPopHeader;
    this.surveyColumns = Object.values(this.appConstants.surveyPopColums);
    this.surveyTableSource = new MatTableDataSource<SurveyTable>(this.data);
    /** console.log(this.surveyTableSource); */
  }

  ngOnInit() {
    console.log('Dialog got', this.data);
  }
  closeDialog() {
    this.dialogRef.close();
  }
}
