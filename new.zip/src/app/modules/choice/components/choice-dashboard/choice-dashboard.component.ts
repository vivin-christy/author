import { Component, OnInit, Output, EventEmitter, ViewChild } from '@angular/core';
import { AppConfig } from '../../../../app.config';
import { MatSort } from '@angular/material/sort';
import { ChoicedashboardDatatableService } from '../../../../services/choicedashboard-datatable.service';
import { ChoicedashboardDatatable } from '../../../../models/choicedashboard-datatable';
import { FormControl } from '@angular/forms';
import { MatTableDataSource, MatDialog } from '@angular/material';
import { ChoiceSurveydialogComponent } from './choice-surveydialog.component';
import { DatePipe } from '@angular/common';


@Component({
  selector: 'app-choice-dashboard',
  templateUrl: './choice-dashboard.component.html',
  styleUrls: ['./choice-dashboard.component.scss']
})
export class ChoiceDashboardComponent implements OnInit {

  appConstants = AppConfig.settings;
  dataTableHeader: any;
  dataTableColumns: any;
  dataTableFillterColumns: any;
  dataTableSource: any = [];
  choicePosNegFlagControl = new FormControl();
  choicePosNegFlagList: any[];
  choiceactiveYnControl = new FormControl();
  choiceactiveYnList: any[];
  pipe:DatePipe;

  @Output() editEvent = new EventEmitter();
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  constructor(
    private appconfig: AppConfig,
    private choiceservice: ChoicedashboardDatatableService,
    private surveyDialog: MatDialog
  ) {
    this.dataTableHeader = this.appConstants.choiceDashboardHeader;
    this.dataTableColumns = Object.values(this.appConstants.choiceDashboardTableColumns).slice();
    this.dataTableFillterColumns = Object.values(this.appConstants.choiceDashboardFillterTableColumns);
    this.choicePosNegFlagList = Object.values(this.appConstants.choicePosNegFlagList);
    this.choiceactiveYnList = Object.values(this.appConstants.choiceActiveYn);
  }

  ngOnInit() {
    this.getDashboard();
    this.dataTableSource.sort = this.sort;
  }
  getDashboard() {
    this.choiceservice.getChoiceDashboard()
      .subscribe(
        dataSource => {
          this.dataTableSource = dataSource,
            this.dataTableSource = new MatTableDataSource<ChoicedashboardDatatable>(this.dataTableSource.content),
            this.dataTableSource.sort = this.sort;
        }
      );
  }
  setupFilter(column: string) {
    console.log(column);
    this.dataTableSource.filterPredicate = (d: ChoicedashboardDatatable, filter: string) => {
      const textToSearch = d[column] && d[column].toLowerCase() || '';
      return textToSearch.indexOf(filter) !== -1;
    };
  }

  applyFilter(filterValue: string) {
    console.log(filterValue);
    this.dataTableSource.filter = filterValue.trim().toLowerCase();
  }

  startEdit(data: any) {
    let inputChoice: any;
    inputChoice = {
      choiceLibraryId: data.choiceLibraryId,
      choiceName: (data.choiceName)? data.choiceName:data.choiceLibraryDesc,
      choiceLibraryDesc: data.choiceLibraryDesc,
      activeYn: (data.activeYn === 'Y') ? true : false,
      posNegFlag: (data.posNegFlag === 'Y' || data.posNegFlag==='P') ? true : false,
      sharedList: {
        sharedListId: '',
        sharedListDesc: ''
      }
    };
    
    console.log('input choice edit',inputChoice);
    this.editEvent.emit(inputChoice);
    //this.dialogRef = this.dialog.open(ChoiceEditComponent, { data });
  }
  openChoiceDialog(row: any) {
    console.log('Row clicked', row);
    const dialog = this.surveyDialog.open(ChoiceSurveydialogComponent, {
      //width: '250px',
      // Can be closed only by clicking the close button
      disableClose: true,
      data: row,
      panelClass: 'surveyModal'
    });
  }

  
  getDates(range, column) {
    const fromDate = this.pipe.transform(range.start, 'yyyy-MM-dd');
    const toDate = this.pipe.transform(range.end, 'yyyy-MM-dd');
    if (column === 'createdDt') {
      this.dataTableSource.data = this.dataTableSource.data.filter(e => e.createdDt > fromDate && e.createdDt < toDate);
    } else {
      this.dataTableSource.data = this.dataTableSource.data.filter(e => e.lastUpdatedDt > fromDate && e.lastUpdatedDt < toDate);
    }
  }
}
