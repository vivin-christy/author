import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';

import { AppConfig } from '../../../app.config';
import { ChoiceDashboardComponent } from '../components/choice-dashboard/choice-dashboard.component';
import { ChoiceCreateComponent } from '../components/choice-create/choice-create.component';
import { ChoiceEditComponent } from '../components/choice-edit/choice-edit.component';
@Component({
  selector: 'app-choice-layout',
  templateUrl: './choice-layout.component.html',
  styleUrls: ['./choice-layout.component.scss']
})
export class ChoiceLayoutComponent implements OnInit {

  appConstants = AppConfig.settings;
  dashboardTitle: string;
  createText: string;
  dialogRef: any;

  validationMSG: any;
  @ViewChild(ChoiceDashboardComponent, { static: false }) private choicedashboard: ChoiceDashboardComponent;

  constructor(
    private appconfig: AppConfig,
    public dialog: MatDialog) {
    this.dashboardTitle = this.appConstants.choiceTitle;
    this.createText = this.appConstants.choiceCreateText;

  }

  ngOnInit() {
  }
  openCreateChoiceComponent(): void {
    this.dialogRef = this.dialog.open(ChoiceCreateComponent,{ panelClass: 'newQuestion', disableClose: true});
    this.dialogRef.afterClosed().subscribe(result => this.choicedashboard.getDashboard());
  }
  OpeneditChoiceComponent(data: any) {
    this.dialogRef = this.dialog.open(ChoiceEditComponent, { data , panelClass: 'newQuestion', disableClose: true} );
    this.dialogRef.afterClosed().subscribe(result => this.choicedashboard.getDashboard());
  }

}
