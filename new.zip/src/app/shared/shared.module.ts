import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SatDatepickerModule, SatNativeDateModule } from 'saturn-datepicker';
import { MatDatepickerModule, MatInputModule, MatNativeDateModule } from '@angular/material';
import { DaterangePickerComponent } from './components/daterange-picker/daterange-picker.component';
import { SearchComponent } from './components/search/search.component';
import { FormsModule } from '@angular/forms';
import { ListFilterPipe } from '../pipes/list-filter.pipe';

@NgModule({
  declarations: [ 
    DaterangePickerComponent,
    SearchComponent,
    ListFilterPipe
  ],
  imports: [
    CommonModule,
    SatDatepickerModule, SatNativeDateModule, MatDatepickerModule, MatInputModule, MatNativeDateModule, 
    FormsModule
  ],
  exports: [
    CommonModule,
    DaterangePickerComponent,
    SearchComponent,
    ListFilterPipe
    
  ]
})
export class SharedModule { }
