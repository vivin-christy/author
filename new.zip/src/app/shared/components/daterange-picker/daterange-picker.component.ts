import { Component, OnInit, ViewChild, Output, EventEmitter } from '@angular/core';
import { SatDatepicker } from 'saturn-datepicker';
@Component({
  selector: 'app-daterange-picker-component',
 // templateUrl: './daterange-picker.component.html',
  styleUrls: ['./daterange-picker.component.scss'],
  template:`
  <mat-form-field appearance="outline">
    <input matInput
      placeholder="Choose a date range"
      [satDatepicker]="picker"
      (dateChange)="emitDates()" 
      >
    <sat-datepicker #picker [rangeMode]="true">
    </sat-datepicker>
    <sat-datepicker-toggle matSuffix [for]="picker"></sat-datepicker-toggle>
  </mat-form-field>`
})
export class DaterangePickerComponent implements OnInit {
@ViewChild('picker', {static:true}) dateInput: SatDatepicker<any>;
@Output() emitRange : EventEmitter <any> = new EventEmitter<any>();
now: Date = new Date();

delay;
  constructor() { }

  ngOnInit() {
  }

  emitDates(){
   const start = this.dateInput.beginDate;
   const end =  this.dateInput.endDate;
   const daterange = {'start': start, 'end': end };   
   
   this.emitRange.emit(daterange);
  }

}
