export interface ChoicedashboardDatatable {
    choiceLibraryId?: number;
    choiceLibraryDesc: string;
    posNegFlag: string;
    activeYn: string;
    createdBy?: string;
    createdDt?: string;
    lastUpdatedBy?: string;
    lastUpdatedDt?: string;
    choiceName?: string;
    sharedList?: [{
        sharedListId?: number,
        sharedListDesc?: string
    }];
    surveyIds?: any;
    surveyLinks?: [
        {
            surveyCode?: any,
            surveyTitle?: any,
            surveyDate?: any
        }
    ];

}
