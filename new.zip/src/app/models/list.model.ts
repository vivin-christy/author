export class List {
    public id: any;
    public value: any;
}

export class categoryList {
    public questionCategoryId: number;
    public questionCategoryDesc: string;
}

export class sharedList {
    public sharedListId: number;
    public sharedListDesc: string;
}
export class choiceList {
    public choiceListId: number;
    public choiceListDesc: string;
}
