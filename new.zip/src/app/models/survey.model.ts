export interface SurveyTable {
    
        
          surveyId:any
             surveyCode:any
            createdDt:any
            

}

