export interface QuestionsModel {
        questionLibraryId?: number,
        genericText: string,
        activeYn: string,
        combinedNormId?: string,
        percentileYn: string,
        questionPosNegFlag: string,
        questionSortOrder?: number,
        summRptYn: string,
        createdBy?: string,
        createdDt?: string,
        lastUpdatedBy?: string,
        lastUpdatedDt?: string,
        questionCategory?: {
            questionCategoryId: number,
            questionCategoryDesc: string,
            activeYn?: string,
            createdBy?: string,
            createdDt?: string,
            lastUpdatedBy?: string,
            lastUpdatedDt?: string
        }
        questionSharedList?: string,
        choiceList?: string
}