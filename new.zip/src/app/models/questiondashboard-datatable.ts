export interface QuestiondashboardDatatable {
    content: [{
        questionLibraryId: any;
        genericText: any;
        activeYn: any;
        combinedNormId: any;
        percentileYn: any;
        questionPosNegFlag: any;
        questionSortOrder: any;
        summRptYn: any;
        createdBy: any;
        createdDt: any;
        lastUpdatedBy: any;
        lastUpdatedDt: any;
        questionCategory: {
            questionCategoryId: any,
            questionCategoryDesc: any,
            activeYn: any,
            createdBy: any,
            createdDt: any,
            lastUpdatedBy: any,
            lastUpdatedDt: any
        };
        surveyIDs: any;
        surveyLinks: [
            {
                surveyCode: any,
                surveyTitle: any,
                surveyDate: any
            }
        ];

    }
    ]
}