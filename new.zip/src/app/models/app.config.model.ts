export interface AppConfigModel {
    env: {
        name: string;
    };
    apiServer: {
        https: string;
        http: string;
    };
    baseurl: string;
    baseurlparam: string;
    /** Question Modules */
    questiontitle: string;
    questionCreateText: string;
    questiondashboardHeader: {
        questionCategory: string;
        genericQuestion: string;
        connotation: string;
        percentile: string;
        summaryReport: string;
        status: string;
        createDate: string;
        modifiedDate: string;
        surveylink: string;
        action: string;
    };
    surveyPopHeader: {
        surveyId: string;
        surveyCode: string;
        createdDt: string;
    };
    questionDashboardTableColumns: {
        category: string;
        genericText: string;
        connotation: string;
        percentile: string;
        summaryreport: string;
        status: string;
        createDate: string;
        modifieddate: string;
        surveylink: string;
        action: string;
    };
    surveyPopColums: {
        surveyId: string;
        surveyCode: string;
        createdDt: string;
    };
    questionDashboardFillterTableColumns: {
        fcategory: string;
        fgenericText: string;
        fconnotation: string;
        fpercentile: string;
        fsummaryreport: string;
        fstatus: string;
        fcreateDate: string;
        fmodifieddate: string;
        fsurveylink: string;
        faction: string;
    };

    connotationList: [
        {
            connotationId: string;
            connotationDesc: string;
        }
    ];

    percentileList: [
        {
            percentileId: string;
            percentileDesc: string;
        }
    ];
    summaryReportList: [
        {
            summaryReportId: string;
            summaryReportDesc: string;
        }
    ];
    statusList: [
        {
            statusId: string;
            statusDesc: string;
        }
    ];
    categoryList: [
        {
            questionCategoryId: string,
            questionCategoryDesc: string
        }
    ];
    QuestionModel: {
        id: number;
        questionCategory: any;
        genericQuestion: string;
        connotation: string;
        percentile: boolean;
        summaryReport: boolean;
        status: boolean;
        questionSharedList: any[];
        choiceList: any[];
    };
    validationMsg: string;
    /** Choice Modules */
    choiceTitle: string;
    choiceCreateText: string;
    choiceDashboardHeader: {
        choiceLibraryDesc: string;
        posNegFlag: string;
        activeYn: string;
        createdBy: string;
        createdDt: string;
        lastUpdatedDt: string;
        surveylink: string;
        action: string;
    };
    choiceDashboardTableColumns: {
        choiceLibraryDesc: string;
        posNegFlag: string;
        activeYn: string;
        createdBy: string;
        createdDt: string;
        lastUpdatedDt: string;
        surveylink: string;
        action: string;
    };
    choiceDashboardFillterTableColumns: {
        fchoiceLibraryDesc: string;
        fposNegFlag: string;
        factiveYn: string;
        fcreatedBy: string;
        fcreatedDt: string;
        flastUpdatedDt: string;
        fsurveylink: string;
        faction: string;
    };
    choiceModel: {
        choiceLibraryId: number;
        choiceLibraryDesc: string;
        posNegFlag: string;
        activeYn: string;
        createdBy?: string;
        createdDt?: string;
        lastUpdatedBy?: string;
        lastUpdatedDt?: string;
        choiceName?: string;
        sharedList?: string;
    };
    choiceCreateLable: {
        id: number;
        questionCategory: string,
        genericQuestion: string;
        connotation: string,
        percentile: string,
        summaryReport: string;
        status: string;
        questionSharedList: string;
        choiceList: string;
        choiceName: string;
    };
    choicePosNegFlagList: [
        {
            choicePosNegFlagId: string;
            choicePosNegFlagDesc: string;
        }
    ];
    choiceActiveYn: [
        {
            activeId: string;
            activeDesc: string;
        }
    ];
    SharedChoiceCreate: string;
    SharedQuestionCreate:string;
    SharedEdit:string;
    SharedListTitle:string;
    SharedChoiceModel:{
        sharedChoiceId:string;
        sharedChoiceName?: string;
        sharedChoiceDesc: string;
        sharedChoiceList: any[];
    }
}
