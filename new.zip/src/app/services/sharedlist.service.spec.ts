import { TestBed } from '@angular/core/testing';

import { SharedlistService } from './sharedlist.service';

describe('SharedlistService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SharedlistService = TestBed.get(SharedlistService);
    expect(service).toBeTruthy();
  });
});
