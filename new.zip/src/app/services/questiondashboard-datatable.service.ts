import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { AppConfig } from '../app.config';
import { QuestiondashboardDatatable } from '../models/questiondashboard-datatable';
import { HttpErrorHandlerService } from '../shared/services/httperrorhandler.service';
import { HandleError } from '../shared/services/httperrorhandler.service';
import { SurveyTable } from '../models/survey.model';


@Injectable({
  providedIn: 'root'
})
export class QuestiondashboardDatatableService {
  public handleError: HandleError;
  protected appConstants = AppConfig.settings;
  constructor(
    private http: HttpClient,
    private httpErrorHandler: HttpErrorHandlerService,
    private appconfig: AppConfig) {

    this.handleError = httpErrorHandler.createHandleError('QuestionDashboardService');


  }
  httpOptions = {
    headers: new HttpHeaders().set('content-type', 'application/json').set('Accept', 'application/json')
      .set('Access-Control-Allow-Origin', '*')
  };
export=`${environment.serverUrl}/questions/download`;
  localUrl = `${environment.serverUrl}/questions`; 
  //localUrl = 'assets/json/sample_question_dashboard.json';
 // url = 'assets/json/survey.json';
  url=`${environment.serverUrl}/surveys`;
  getQuestionDashboard(): Observable<QuestiondashboardDatatable[]> {
    return this.http.get<QuestiondashboardDatatable[]>(this.localUrl, this.httpOptions)
      .pipe(
        catchError(this.handleError('getQuestionDashboard', []))
      );
  }
   getSurveyTable(id: any): Observable<SurveyTable[]> {
      return this.http.get<SurveyTable[]>(`${this.url}/${id}`, this.httpOptions)
        .pipe(
          catchError(this.handleError('getSurveyTable', []))
        );
    } 
}
