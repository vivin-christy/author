import { Injectable } from '@angular/core';
import { HttpErrorHandlerService, HandleError } from '../shared/services/httperrorhandler.service';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { List } from '../models/list.model';
import { catchError, map } from 'rxjs/operators';
//const url = 'shared';
@Injectable({
  providedIn: 'root'
})
export class SharedlistService {

  public handleError: HandleError;
  constructor( 
    private http: HttpClient,
    private httpErrorHandler: HttpErrorHandlerService,
    ) { 
      this.handleError = httpErrorHandler.createHandleError('SharedlistService')
    }

    getSharedQuestions():Observable<any[]> {
      const url="assets/json/shared.json";
      return this.http.get<any[]>(url)
      .pipe(
        (map(res => res),
        catchError(this.handleError('getSharedQuestions',[]))
      ))
    }
}
