import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { throwError, Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { catchError, map } from 'rxjs/operators';

// const apiUrl = environment.name;
//const apiUrl = environment.serverUrl;

@Injectable({
  providedIn: 'root'
})
export class CommonService {
 // apiUrl = 'api/Questions';
 public apiUrl = environment.serverUrl;
  httpOptions = {
    headers: new HttpHeaders().set('content-type', 'application/json').set('Accept', 'application/json')
    .set('Access-Control-Allow-Origin', '*')
  };

  constructor( private http: HttpClient ) { }

  private handleError(errorResponse: HttpErrorResponse) {
    if (errorResponse instanceof ErrorEvent) {
      console.error('Client side error', errorResponse.error.message);
    } else {
      console.error('Server side error', errorResponse);
    }
    return throwError(errorResponse);
  }

  insert(url, inputData): Observable<any> {
    console.log('apiUrl', this.apiUrl);
    return this.http.post(`${this.apiUrl}/${url}`, inputData)
    .pipe(
      (map(res => res),
      (catchError(this.handleError))
    ));
  }

  edit(url, id: any): Observable<any> {
    return this.http.get(`${this.apiUrl}/${url}`, id)
    .pipe(
      (map(res => res),
      (catchError(this.handleError))
    ));
  }

   update(url, inputData: any): Observable<any> {
    return this.http.put(`${this.apiUrl}/${url}`, inputData)
    .pipe(
      (map(res => res),
      (catchError(this.handleError))
    ));
  }

  exportExcel(url, filename){
    console.log('this', `${this.apiUrl}/${url}`);//responseType: 'arraybuffer',headers:headers
    return this.http.get(`${this.apiUrl}/${url}`,{observe: 'response', responseType: 'arraybuffer'})
    .pipe(
      (map(res => {
        let data = {
          fileContent: new Blob([res.body], {type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'}),
          filename: filename // res.headers.get('filename')
       }
return data ;
      })),
      catchError(this.handleError)
    );
  }


}
