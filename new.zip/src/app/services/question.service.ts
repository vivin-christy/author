import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { environment } from 'src/environments/environment';
import { catchError, tap, map } from 'rxjs/operators';
import { List } from '../models/list.model';

// const apiUrl = environment.name;

@Injectable({
  providedIn: 'root'
})
export class QuestionService {
  public apiUrl = environment.serverUrl;
//  apiUrl = 'api';

  httpOptions = {
    headers: new HttpHeaders().set('Content-Type', 'application/json').set('Accept', 'application/json')
  };

  constructor( private http: HttpClient ) { }

  private handleError(errorResponse: HttpErrorResponse) {
    if (errorResponse instanceof ErrorEvent) {
      console.error('Client side error', errorResponse.error.message);
    } else {
      console.error('Server side error', errorResponse);
    }
    console.error('error', errorResponse);
    
    return throwError(errorResponse);
  }


  getCategoryList(): Observable<any> {
    console.log('apiUrl', this.apiUrl);
   // const url = `${this.apiUrl}/categories`;
    const url = `${this.apiUrl}/categories?page=1`;
    return this.http.get<List[]>(url, this.httpOptions).pipe(
      map( res => res),
      catchError(this.handleError)
    );
  }

  getSharedList(): Observable<any> {
    //const url = `${this.apiUrl}/sharedlist`;
    const url="assets/json/shared.json";
    return this.http.get<List[]>(url, this.httpOptions).pipe(
      map( res => res),
      catchError(this.handleError)
    );
  }

  getChoiceList(): Observable<any> {
  //  const url = `${this.apiUrl}/choicelist`;
    const url="assets/json/shared.json";
    return this.http.get<List[]>(url, this.httpOptions).pipe(
      map( res => res),
      catchError(this.handleError)
    );
  }

  /*
// Get Choice dropdown data
getChoiceList(id): Observable<List[]>{
  let url = 'https://jsonplaceholder.typicode.com/posts?userId='+id;
  return this.http.get<List[]>(url).pipe(
    tap(data => console.log(data)),
    catchError(this.handleError)
  )
}
*/

}
