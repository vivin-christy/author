import { Injectable } from '@angular/core';
import { HandleError, HttpErrorHandlerService } from '../shared/services/httperrorhandler.service';
import { AppConfig } from '../app.config';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { ChoicedashboardDatatable } from '../models/choicedashboard-datatable';
@Injectable({
  providedIn: 'root'
})
export class ChoicedashboardDatatableService {

  public handleError: HandleError;
  protected appConstants = AppConfig.settings;
  constructor(
    private http: HttpClient,
    private httpErrorHandler: HttpErrorHandlerService,
    private appconfig: AppConfig) {

    this.handleError = httpErrorHandler.createHandleError('choiceDashboardService');
  }
  httpOptions = {
    headers: new HttpHeaders().set('content-type', 'application/json').set('Accept', 'application/json')
      .set('Access-Control-Allow-Origin', '*')
  };
  localUrl = `${environment.serverUrl}/choices`; 
 // localUrl = 'assets/json/sample_choice_dashboard.json';
  getChoiceDashboard(): Observable<ChoicedashboardDatatable[]> {
    return this.http.get<ChoicedashboardDatatable[]>(this.localUrl, this.httpOptions)
      .pipe(
        catchError(this.handleError('getChoiceDashboard', []))
      );
  }
}
