import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AppSingletonService {

  constructor() {
    console.log('App singletonService');
  }
}
